﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            listBox1.Items.Clear();

            string conStr = string.Format("SELECT DISTINCT Country AS 'Страна'\r\nFROM Tours\r\nWHERE DurationDays < 7\r\nORDER BY Country ASC;");
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            listBox1.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            string conStr = string.Format("SELECT\r\n    t.TourID AS 'ID тура',\r\n    t.Country AS 'Страна',\r\n    t.DurationDays AS 'Продолжительность (дней)',\r\n    t.Price AS 'Цена',\r\n    COALESCE(SUM(s.Quantity), 0) AS 'Общее количество реализованных путёвок'\r\nFROM Tours t\r\nLEFT JOIN Sales s ON t.TourID = s.TourID\r\nGROUP BY t.TourID, t.Country, t.DurationDays, t.Price\r\nORDER BY 'Общее количество реализованных путёвок' DESC;");
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            listBox1.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            string conStr = string.Format("SELECT TOP 3\r\n    c.ClientID AS 'ID клиента',\r\n    c.FullName AS 'ФИО клиента',\r\n    c.Phone AS 'Телефон',\r\n    SUM(s.Quantity) AS 'Всего куплено путёвок'\r\nFROM Clients c\r\nJOIN Sales s ON c.ClientID = s.ClientID\r\nGROUP BY c.ClientID, c.FullName, c.Phone\r\nORDER BY 'Всего куплено путёвок' DESC;");
            using (SqlConnection con = new SqlConnection(Program.conStr))
            {
                try
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(conStr, con);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string row = null;
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                row += reader.GetName(i) + " : " + reader[i] + " ";
                            }
                            listBox1.Items.Add(row);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }
    }
}
